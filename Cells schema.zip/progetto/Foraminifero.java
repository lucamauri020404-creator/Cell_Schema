import java.util.Set;

public class Foraminifero extends Eucariota {
    private double energiaMediaIngerita;
    private Tipologia tipologia;

    public Foraminifero(String nome, long lunghezzaDna, float volumeMedio, int numeroRibosomi, float dimensioniNucleo, Set<TipoRiproduzione> tipiRiproduzione, double energiaMediaIngerita, Tipologia tipologia) {
        super(nome, lunghezzaDna, volumeMedio, numeroRibosomi, dimensioniNucleo, tipiRiproduzione);
        this.energiaMediaIngerita = energiaMediaIngerita;
        this.tipologia = tipologia;
    }

    @Override
    public double calcolaEnergiaProdotta() {
        return 0.53 * energiaMediaIngerita;
    }
    public Tipologia getTipologia() { return tipologia; }

}

