public enum TipoRiproduzione {
    MITOSI, MEIOSI
}