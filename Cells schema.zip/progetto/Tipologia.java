public enum Tipologia {
    PLANCTONICO, BENTONICO
}
