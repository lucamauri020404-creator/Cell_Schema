import java.util.Set;

public class Alga extends Eucariota {
    private float efficienzaEnergetica;
    private float irraggiamentoSolareMedio;
    private Morfologia morfologia;

    public Alga(String nome, long lunghezzaDna, float volumeMedio, int numeroRibosomi, float dimensioniNucleo, Set<TipoRiproduzione> tipiRiproduzione, float efficienzaEnergetica, float irraggiamentoSolareMedio, Morfologia morfologia) {
        super(nome, lunghezzaDna, volumeMedio, numeroRibosomi, dimensioniNucleo, tipiRiproduzione);
        this.efficienzaEnergetica = efficienzaEnergetica;
        this.irraggiamentoSolareMedio = irraggiamentoSolareMedio;
        this.morfologia = morfologia;
    }

    @Override
    public double calcolaEnergiaProdotta() {
        return (efficienzaEnergetica / 100.0) * irraggiamentoSolareMedio;
        
    }
    public Morfologia getMorfologia() { return morfologia; }

}

