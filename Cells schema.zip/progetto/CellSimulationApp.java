import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class CellSimulationApp {

    private static final Random random = new Random();
    private static final List<Eucariota> popolazione = new ArrayList<>();

    // Generatore casuale di Alghe
    public static Alga generaAlgaCasuale(int id) {
        float efficienza = 1.5f + random.nextFloat() * (3.0f - 1.5f);
        float irraggiamento = 500f + random.nextFloat() * (700f - 500f);
        Morfologia[] morfologie = Morfologia.values();
        Morfologia m = morfologie[random.nextInt(morfologie.length)];
        
        Set<TipoRiproduzione> riproduzione = random.nextBoolean() ? 
            Set.of(TipoRiproduzione.MITOSI) : Set.of(TipoRiproduzione.MITOSI, TipoRiproduzione.MEIOSI);

        return new Alga("Alga_" + id, random.nextLong(1000, 5000), 12.5f, 
            random.nextInt(10, 500), 4.2f, riproduzione, efficienza, irraggiamento, m);
    }

    // Generatore casuale di Foraminiferi
    public static Foraminifero generaForaminiferoCasuale(int id) {
        double energiaIngerita = 50.0 + random.nextDouble() * 150.0;
        Tipologia[] tipologie = Tipologia.values();
        Tipologia t = tipologie[random.nextInt(tipologie.length)];
        
        Set<TipoRiproduzione> riproduzione = Set.of(TipoRiproduzione.MITOSI);

        return new Foraminifero("Foraminifero_" + id, random.nextLong(2000, 8000), 25.0f, 
            random.nextInt(50, 800), 8.5f, riproduzione, energiaIngerita, t);
    }

    public static void main(String[] args) throws IOException {
        // Generiamo i 120 elementi all'avvio del server
        for (int i = 1; i <= 60; i++) {
            popolazione.add(generaAlgaCasuale(i));
            popolazione.add(generaForaminiferoCasuale(i));
        }

        // Creiamo il server HTTP sulla porta 8080
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        
        // Mappatura degli endpoint richiesti
        server.createContext("/lista-ordinata-ribosomi", new ListaOrdinataHandler());
        server.createContext("/cellula-maggiore-energia", new TopEnergiaHandler());
        
        server.setExecutor(null); // default executor
        server.start();
        
        System.out.println("\n==================================================");
        System.out.println("   SERVER HTTP ATTIVO SULLA PORTA 8080");
        System.out.println("==================================================");
        System.out.println("Endpoint 1: http://localhost:8080/lista-ordinata-ribosomi");
        System.out.println("Endpoint 2: http://localhost:8080/cellula-maggiore-energia");
        System.out.println("Premere il tasto 'Stop' in VS Code per spegnere.");
        System.out.println("==================================================");
    }

    // Gestore per l'endpoint: LISTA ORDINATA PER NUMERO RIBOSOMI (CRESCENTE)
    static class ListaOrdinataHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Ordiniamo una copia della lista per non alterare l'originale ad ogni chiamata
            List<Eucariota> ordinata = new ArrayList<>(popolazione);
            ordinata.sort(Comparator.comparingInt(Eucariota::getNumeroRibosomi));

            StringBuilder sb = new StringBuilder();
            sb.append("<h1>==================================================</h1>");
            sb.append("<h1>   LISTA ORDINATA PER NUMERO RIBOSOMI (CRESCENTE) </h1>");
            sb.append("<h1>==================================================</h1><ul>");
            for (Eucariota e : ordinata) {
                sb.append("<li>").append(e.toString()).append("</li>");
            }
            sb.append("</ul>");

            inviaRispostaHttp(exchange, sb.toString());
        }
    }

    // Gestore per l'endpoint: CELLULA CON MAGGIORE ENERGIA PRODOTTA
    static class TopEnergiaHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (popolazione.isEmpty()) {
                inviaRispostaHttp(exchange, "Nessun dato disponibile.");
                return;
            }

            Eucariota top = popolazione.stream()
                .max(Comparator.comparingDouble(Eucariota::calcolaEnergiaProdotta))
                .orElse(popolazione.get(0));

            StringBuilder sb = new StringBuilder();
            sb.append("<h1>==================================================</h1>");
            sb.append("<h1>      CELLULA CON MAGGIORE ENERGIA PRODOTTA       </h1>");
            sb.append("<h1>==================================================</h1>");
            sb.append("<p><b>Nome:</b> ").append(top.getNome()).append("</p>");
            sb.append("<p><b>Tipo Organismo:</b> ").append(top.getClass().getSimpleName()).append("</p>");
            sb.append(String.format("<p><b>Energia prodotta totale:</b> %.2f</p>", top.calcolaEnergiaProdotta()));
            sb.append("<h1>==================================================</h1>");

            inviaRispostaHttp(exchange, sb.toString());
        }
    }

    // Metodo di utilità per inviare la risposta al browser con codifica UTF-8 corretta
    private static void inviaRispostaHttp(HttpExchange exchange, String risposta) throws IOException {
        byte[] bytes = risposta.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}

