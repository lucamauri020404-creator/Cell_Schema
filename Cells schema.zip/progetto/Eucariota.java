import java.util.Set;

public abstract class Eucariota {
    private String nome;
    private long lunghezzaDna;
    private float volumeMedio;
    private int numeroRibosomi;
    private float dimensioniNucleo;
    private Set<TipoRiproduzione> tipiRiproduzione;

    public Eucariota(String nome, long lunghezzaDna, float volumeMedio, int numeroRibosomi, float dimensioniNucleo, Set<TipoRiproduzione> tipiRiproduzione) {
        this.nome = nome;
        this.lunghezzaDna = lunghezzaDna;
        this.volumeMedio = volumeMedio;
        this.numeroRibosomi = numeroRibosomi;
        this.dimensioniNucleo = dimensioniNucleo;
        this.tipiRiproduzione = tipiRiproduzione;
    }

    public abstract double calcolaEnergiaProdotta();

    // Tutti i Getter per utilizzare le variabili ed eliminare i warning
    public String getNome() { return nome; }
    public long getLunghezzaDna() { return lunghezzaDna; }
    public float getVolumeMedio() { return volumeMedio; }
    public int getNumeroRibosomi() { return numeroRibosomi; }
    public float getDimensioniNucleo() { return dimensioniNucleo; }
    public Set<TipoRiproduzione> getTipiRiproduzione() { return tipiRiproduzione; }
    
    @Override
    public String toString() {
        return String.format("%s [Ribosomi: %d, Energia: %.2f]", 
            nome, numeroRibosomi, calcolaEnergiaProdotta());
    }
}
